import top from '../../img/kaisen.png';
import produto1 from '../../img/download.png';
import produto2 from '../../img/harry.png';
import produto3 from '../../img/patrickstar.jpg';
const carrinho2 = {
    topo:{
        titulo:"Jola Iluak",
        imagem: top,
    },
    detalhes4:{
        titulo:"Detalhes do Carrinho 3",
        tituloProduto: "Produto 005",
        descricao:"blusa Moletom Pink Floyd",
        preco:"R$ 200,00",
        imagem:produto2
    },

    detalhes5:{
        titulo:"Detalhes do Carrinho 4",
        tituloProduto: "Produto 006",
        descricao:"",
        preco:"R$ 100,00",
        imagem:produto1
    },
    itens2:{
        titulo:"Itens do carrinho2",
        lista:[
            {
                nome: "Produto 005",
                descricao:"",
                preco:"R$ 200,00",
                imagem:produto1
            },
            {
                nome: "Produto 006",
                descricao:"Harry potter Brinquedo",
                preco:"R$ 100,00",
                imagem:produto2
            },
            {
                nome: "Produto 007",
                descricao:"Patrick estrela ",
                preco:"R$ 521310,00",
                imagem:produto3
            },
        ]
    }
}
export default carrinho2;    